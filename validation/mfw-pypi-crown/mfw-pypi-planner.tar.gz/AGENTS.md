# PyPI planner bridge agent law

This directory is governed by the repository root `AGENTS.md` and `CHATGPT-CLOUD-AGENTS.md` plus these tighter rules.

- The bridge manufactures planning candidates; it never actuates them.
- Runtime dependency installation, network access, shell execution, and subprocess planner discovery are forbidden. Dependencies are admitted at environment-construction time through PyPI metadata.
- The canonical execution boundary is PDDL domain + problem -> Unified Planning engine -> bounded candidate plan + JSON evidence.
- Every candidate remains unadmitted until the independent MFW validator emits its own receipt.
- Preserve the native plan kind in evidence. A lossy projection must be named; an unavailable safe projection is `REFUSED:unrepresentable_plan_kind`.
- Engine discovery is dynamic from Unified Planning's installed factory. Never hard-code an installed-engine claim.
- Non-default plugins enter only through explicit canonical module import or `NAME=MODULE:CLASS` registration; never scan/import every installed distribution ambiently.
- Add one positive and one negative test for every new semantic consequence.
