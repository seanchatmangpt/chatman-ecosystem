---- MODULE BRCEReference ----
EXTENDS Naturals, Sequences, FiniteSets

VARIABLES phase, authority, receipt, verified, standing, consequenceCount

Init ==
    /\ phase = "RECEIVED"
    /\ authority = FALSE
    /\ receipt = FALSE
    /\ verified = FALSE
    /\ standing = FALSE
    /\ consequenceCount = 0

Parse ==
    /\ phase = "RECEIVED"
    /\ phase' = "PARSED"
    /\ UNCHANGED <<authority, consequenceCount, receipt, standing, verified>>

Route ==
    /\ phase = "PARSED"
    /\ phase' = "ROUTED"
    /\ UNCHANGED <<authority, consequenceCount, receipt, standing, verified>>

Admit ==
    /\ phase = "ROUTED"
    /\ phase' = "ADMITTED"
    /\ UNCHANGED <<authority, consequenceCount, receipt, standing, verified>>

Construct ==
    /\ phase = "ADMITTED"
    /\ phase' = "CONSTRUCTED"
    /\ UNCHANGED <<authority, consequenceCount, receipt, standing, verified>>

Authorize ==
    /\ phase = "CONSTRUCTED"
    /\ authority' = TRUE
    /\ phase' = "AUTHORIZED"
    /\ UNCHANGED <<consequenceCount, receipt, standing, verified>>

Actuate ==
    /\ phase = "AUTHORIZED" /\ authority
    /\ consequenceCount' = consequenceCount + 1
    /\ phase' = "EXECUTED"
    /\ UNCHANGED <<authority, receipt, standing, verified>>

Receipt ==
    /\ phase = "EXECUTED"
    /\ phase' = "RECEIPTED"
    /\ receipt' = TRUE
    /\ UNCHANGED <<authority, consequenceCount, standing, verified>>

Verify ==
    /\ phase = "RECEIPTED" /\ receipt
    /\ phase' = "VERIFIED"
    /\ verified' = TRUE
    /\ UNCHANGED <<authority, consequenceCount, receipt, standing>>

GrantStanding ==
    /\ phase = "VERIFIED" /\ receipt /\ verified
    /\ phase' = "STANDING"
    /\ standing' = TRUE
    /\ UNCHANGED <<authority, consequenceCount, receipt, verified>>

Next ==
    \/ Parse
    \/ Route
    \/ Admit
    \/ Construct
    \/ Authorize
    \/ Actuate
    \/ Receipt
    \/ Verify
    \/ GrantStanding

vars == <<phase, authority, receipt, verified, standing, consequenceCount>>

Spec == Init /\ [][Next]_vars /\ WF_vars(Next)

NoStandingWithoutReceipt ==
    ~standing \/ receipt

NoStandingWithoutVerification ==
    ~standing \/ verified

AtMostOneConsequence ==
    consequenceCount <= 1

ExecutedRequiresAuthority ==
    phase # "EXECUTED" \/ authority

AdmittedEventuallyTerminal ==
    phase = "ADMITTED" ~> phase \in {"RECEIPTED", "VERIFIED", "STANDING"}

====
