# MFW PyPI planner bridge

This package exposes the official Unified Planning engine federation to MFW without adding runtime package installation or ambient actuation.

## Environment construction

Install one bounded engine family:

```bash
python -m pip install './tools/mfw-pypi-planner[pyperplan]'
```

Install every engine in Unified Planning's official `engines` extra:

```bash
python -m pip install './tools/mfw-pypi-planner[engines]'
```

Install maintained/community Python plugins independently:

```bash
python -m pip install './tools/mfw-pypi-planner[tamerlite]'
mfw-pypi-planner catalog --register tamerlite=tamerlite.engine:TamerLite

python -m pip install './tools/mfw-pypi-planner[paraspace]'
mfw-pypi-planner catalog --load-module up_paraspace
```

The registration surface is generic: any already-installed Unified Planning-compatible PyPI engine can be admitted with `--register NAME=MODULE:CLASS`, while self-registering packages use `--load-module MODULE`. No package installation or ambient plugin scan occurs at runtime.

Install the official engine federation plus all known separately distributed plugins:

```bash
python -m pip install './tools/mfw-pypi-planner[all]'
```

No package installation occurs inside `mfw-pypi-planner` at runtime. Spiderplan is installable from PyPI but its solver execution separately requires Docker; package registration is not promoted into solver-execution standing.

## Capability inventory

```bash
mfw-pypi-planner catalog
```

The JSON inventory is derived from the installed Unified Planning factory after explicit plugin admission. Package metadata is not promoted into an engine-availability claim.

## Candidate manufacture

```bash
mfw-pypi-planner solve \
  --domain domain.pddl \
  --problem problem.pddl \
  --plan runs/candidate.plan \
  --engine pyperplan \
  --mode classical \
  --timeout 30 \
  --register tamerlite=tamerlite.engine:TamerLite
```

`--engine auto` lets Unified Planning select an installed compatible engine from the admitted problem kind. Sequential and time-triggered plans enter the existing MFW textual candidate boundary. Hierarchical plans may expose an action-plan projection, which is explicitly marked lossy. Other plan kinds receive `REFUSED:unrepresentable_plan_kind` rather than silent flattening.

Use `mfw-planner/engines-python.toml` with the existing Rust runner:

```bash
cargo run -p mfw-planner -- \
  --engines mfw-planner/engines-python.toml \
  solve \
  --planner classical \
  --domain /absolute/domain.pddl \
  --problem /absolute/problem.pddl \
  --run-dir /absolute/runs/python-001 \
  --set python_engine=pyperplan
```

The Python bridge only manufactures a candidate. The configuration deliberately retains VAL as the independently receipted validator; no Python candidate receives standing by construction alone.

## Scope boundary

The bridge covers the MFW PDDL rail through Unified Planning: classical, numeric, temporal, hierarchical, multi-agent, validation, compilation, and the operation modes exposed by explicitly admitted installed PyPI plugins. The stable official engine set is closed by `[engines]`; generic registration preserves lawful extension to future packages without modifying MFW. RL environments, RDDL simulators, and arbitrary Python domain objects are adjacent planning substrates, not equivalent PDDL candidates, and are not mislabeled as closure here.
